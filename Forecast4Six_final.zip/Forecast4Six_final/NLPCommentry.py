# NLPCommentry.py

import os
import joblib
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer

# Path where the model will be saved
model_path = "event_classifier_model.joblib"

# Sample dataset (used only if model doesn't exist)
sample_data = [
    ("What a shot! That's gone for four.", "FOUR"),
    ("He hits it high... and it's a SIX!", "SIX"),
    ("Clean bowled! The stumps are shattered.", "WICKET"),
    ("Dot ball. No run.", "OTHER"),
    ("He goes for a big one and it's out!", "WICKET"),
    ("Brilliant drive through covers. FOUR!", "FOUR"),
    ("Massive hit over long-on. That's a SIX!", "SIX"),
    ("Careful defense. Just one run.", "OTHER"),
    ("Oh no! He's given LBW.", "WICKET"),
    ("Drives through mid-off for a boundary!", "FOUR"),
    ("It's gone all the way! SIX runs!", "SIX"),
    ("Slower ball, beats the bat.", "OTHER"),
    ("Caught behind! That's a huge breakthrough.", "WICKET"),
    ("Pull shot, and it's FOUR!", "FOUR"),
    ("Lofted shot over extra cover, SIX!", "SIX"),
    ("Taps it gently. No run.", "OTHER"),
    ("Edge and taken! WICKET!", "WICKET"),
    ("Perfect timing. FOUR runs!", "FOUR"),
    ("Flat batted over mid-on. SIX!", "SIX"),
    ("Blocked out safely.", "OTHER")
]

# Function to train and save the model (only runs once)
def train_and_save_model():
    df = pd.DataFrame(sample_data, columns=["commentary", "event"])
    X = df["commentary"]
    y = df["event"]
    
    model = Pipeline([
        ('tfidf', TfidfVectorizer()),
        ('clf', LogisticRegression())
    ])
    
    model.fit(X, y)
    joblib.dump(model, model_path)
    return model

# Load or train model
if os.path.exists(model_path):
    model = joblib.load(model_path)
else:
    model = train_and_save_model()

# Main function to use in dashboard
def predict_event_only(commentary: str) -> str:
    if not commentary.strip():
        return "Empty Input"
    return model.predict([commentary])[0]
