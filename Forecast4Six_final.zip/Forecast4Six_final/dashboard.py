# dashboard.py

import streamlit as st
import pandas as pd
import os
from datetime import datetime
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np

# ✅ Import classifier from NLPCommentry.py
from NLPCommentry import predict_event_only

# =========================
# Page Setup
# =========================
st.set_page_config(page_title="🏏 Forecast4Six", layout="wide")

# =========================
# Header
# =========================
st.markdown("""
    <style>
        .header-container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 9999;
            background-color: #0E1117;
            padding: 20px;
            border-bottom: 1px solid #1F618D;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 0 0 6px 6px;
        }
        .header-logo {
            height: 60px;
            width: 60px;
            margin-right: 15px;
            border-radius: 10px;
        }
        .header-text {
            color: white;
        }
    </style>
    <div class="header-container">
        <img class="header-logo" src="https://png.pngtree.com/png-vector/20250205/ourlarge/pngtree-colorful-cricket-logo-png-image_15400401.png"/>
        <div class="header-text">
            <h1>Forecast4Six</h1>
            <p>Where Cricket Meets AI Magic</p>
        </div>
    </div>
""", unsafe_allow_html=True)

# Add padding below fixed header
st.markdown("<div style='margin-top:100px'></div>", unsafe_allow_html=True)

# =========================
# Sidebar
# =========================
st.sidebar.image(
    "https://i.pinimg.com/736x/96/21/49/962149f905f2598b3e71887fafb2708f.jpg",
    use_container_width=True
)
st.sidebar.title("📱 Forecast4Six")
st.sidebar.markdown("Your AI-Powered Cricket Companion 🧠")

app_mode = st.sidebar.radio("Go to Section", [
    "🏟️ Live & Past Matches",
    "📊 Score Predictor",
    "🗣️ NLP Commentary Classifier",
    "🌦️ Match Weather Forecast"
])

# =========================
# File Paths & Data
# =========================
IPL_FILE = "ipl.csv"
WEATHER_FILES = {
    "India vs Australia (Mumbai)": "India_vs_Australia_Mumbai_forecast.csv",
    "England vs South Africa (Delhi)": "England_vs_South_Africa_Delhi_forecast.csv",
    "Pakistan vs Bangladesh (Chennai)": "Pakistan_vs_Bangladesh_Chennai_forecast.csv"
}

ipl_data = pd.read_csv(IPL_FILE)

# =========================
# 1. Live & Past Matches
# =========================
if app_mode == "🏟️ Live & Past Matches":
    st.title("🏟️ Live & Past Matches")
    st.image(
        "https://images.indianexpress.com/2024/06/premium-35.jpg",
        caption="T20 Match in Action",
        use_container_width=True
    )

    st.subheader("📈 IPL Match Dataset Overview")
    st.dataframe(ipl_data.head(100))

    st.subheader("🔍 Search Matches by Team")
    team_input = st.text_input("Enter team name:")
    if team_input:
        team_cols = [col for col in ipl_data.columns if 'team' in col.lower()]
        if len(team_cols) >= 2:
            team_col_1, team_col_2 = team_cols[:2]
            filtered = ipl_data[
                ipl_data[team_col_1].str.contains(team_input, case=False, na=False) |
                ipl_data[team_col_2].str.contains(team_input, case=False, na=False)
            ]
            st.write(f"Found {len(filtered)} matches:")
            st.dataframe(filtered)
        else:
            st.warning("❗ Dataset doesn't have expected team columns (like 'team1' or 'team2').")

# =========================
# 2. Score Predictor
# =========================
elif app_mode == "📊 Score Predictor":
    st.title("📊 Score Predictor")
    st.image(
        "https://i.pinimg.com/736x/ca/42/b5/ca42b5b8ce50d3494ae52cc0306c78ca.jpg",
        caption="Scoreboard and Cricket Field",
        use_container_width=True
    )

    X = ipl_data.iloc[:, [7, 8, 9, 12, 13]].values
    y = ipl_data.iloc[:, 14].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    runs = st.number_input('Runs', value=100)
    wickets = st.number_input('Wickets', value=2)
    overs = st.number_input('Overs', value=10)
    striker = st.number_input("Striker's Score", value=30)
    non_striker = st.number_input("Non-Striker's Score", value=20)
    model_choice = st.radio('Choose Model', ['Linear Regression', 'Random Forest'])

    if st.button("Predict Score"):
        model = LinearRegression() if model_choice == 'Linear Regression' else RandomForestRegressor(n_estimators=100, max_features=None, random_state=0)
        model.fit(X_train, y_train)
        input_data = scaler.transform([[runs, wickets, overs, striker, non_striker]])
        prediction = model.predict(input_data)[0]
        st.success(f"🏏 Predicted Final Score: **{round(prediction)}**")

# =========================
# 3. NLP Commentary Classifier
# =========================
elif app_mode == "🗣️ NLP Commentary Classifier":
    st.title("🗣️ NLP Commentary Classifier")
    st.markdown("Enter a cricket commentary line and the app will classify it as **FOUR**, **SIX**, **WICKET**, or **OTHER** using machine learning.")

    user_input = st.text_input("🎧 Enter Cricket Commentary:")
    if st.button("Predict Event"):
        if not user_input.strip():
            st.warning("⚠️ Please enter some text.")
        else:
            result = predict_event_only(user_input)
            st.success(f"🏏 Predicted Event: **{result}**")

# =========================
# 4. Match Weather Forecast
# =========================
elif app_mode == "🌦️ Match Weather Forecast":
    st.title("🌦️ Match Weather Forecast")
    st.image(
        "https://i.pinimg.com/736x/01/97/9c/01979cf1b2debf9e52872adf25cf3e5c.jpg",
        caption="Rain Interruptions Can Change Everything!",
        use_container_width=True
    )

    match_choice = st.selectbox("Select Match", list(WEATHER_FILES.keys()))
    file_name = WEATHER_FILES[match_choice]

    if os.path.exists(file_name):
        try:
            df_weather = pd.read_csv(file_name)
            st.subheader(f"📈 Forecast for {match_choice}")
            st.dataframe(df_weather)

            if 'Weather' not in df_weather.columns:
                st.warning("⚠️ 'Weather' column not found in CSV.")
            elif any("rain" in str(w).lower() for w in df_weather['Weather']):
                st.error("🚨 Rain Alert: Rain may affect the match!")
            else:
                st.success("✅ Clear Weather: Match should proceed smoothly.")

            st.download_button("📅 Download Weather CSV", df_weather.to_csv(index=False), file_name=file_name, mime="text/csv")
        except Exception as e:
            st.error(f"⚠️ Error reading forecast file: {e}")
    else:
        st.warning(f"📂 Forecast file '{file_name}' not found. Please upload or check the path.")
