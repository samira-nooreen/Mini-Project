import streamlit as st
import requests
import pandas as pd
from datetime import datetime, timedelta

# Page setup
st.set_page_config(page_title="🏏 Cricket Match Forecast", layout="centered")
st.title("🏏 Cricket Match Weather Forecast with Alerts & CSV Export")
st.write("📅 Forecasts available for the next 5 days in 3-hour intervals.")

# API Setup
API_KEY = "dd34962c3fd351f4e9de3b50c2a00df0"
BASE_URL = "http://api.openweathermap.org/data/2.5/forecast"

# Match schedule
st.markdown("### 📋 Upcoming Matches")
matches = {
    "India vs Australia (Mumbai)": ("Mumbai,IN", datetime.today().date() + timedelta(days=1)),
    "England vs South Africa (Delhi)": ("Delhi,IN", datetime.today().date() + timedelta(days=2)),
    "Pakistan vs Bangladesh (Chennai)": ("Chennai,IN", datetime.today().date() + timedelta(days=3)),
}
match_choice = st.selectbox("Choose a match:", list(matches.keys()))
city, match_date = matches[match_choice]

st.markdown(f"""
**📍 City**: {city}  
**📆 Match Date**: {match_date}
""")

# ✅ Function to render fully left-aligned HTML table
def render_left_aligned_table(df):
    headers = df.columns.tolist()
    rows = df.values.tolist()

    table_html = """
    <style>
        .custom-table {
            width: 100%;
            border-collapse: collapse;
            font-family: sans-serif;
            color: white;
        }
        .custom-table tr:nth-child(even) {
            background-color: #2c2c2c;
        }
        .custom-table tr:nth-child(odd) {
            background-color: #1e1e1e;
        }
        .custom-table th, .custom-table td {
            padding: 8px;
            border-bottom: 1px solid #444;
        }
    </style>
    <table class="custom-table">
        <thead>
            <tr>""" + "".join([f"<th style='text-align:left'>{col}</th>" for col in headers]) + "</tr></thead><tbody>"

    for row in rows:
        table_html += "<tr>" + "".join([f"<td style='text-align:left'>{cell}</td>" for cell in row]) + "</tr>"

    table_html += "</tbody></table>"
    st.markdown(table_html, unsafe_allow_html=True)

# Forecast logic
if st.button("Get Forecast"):
    try:
        today = datetime.today().date()
        max_date = today + timedelta(days=5)

        if not (today <= match_date <= max_date):
            st.warning("❗ Forecast only available for the next 5 days.")
        else:
            params = {"q": city, "appid": API_KEY, "units": "metric"}
            response = requests.get(BASE_URL, params=params)
            data = response.json()

            with st.expander("🔍 Raw API Output"):
                st.json(data)

            if data.get("cod") != "200":
                st.error(f"❌ API Error: {data.get('message', 'Unknown error')}")
            else:
                match_date_str = match_date.strftime("%Y-%m-%d")
                forecast_data = []
                rain_expected = False

                st.subheader(f"📊 Forecast for {match_choice}")

                for item in data["list"]:
                    if match_date_str in item["dt_txt"]:
                        dt_txt = item["dt_txt"]
                        temp = item["main"]["temp"]
                        humidity = item["main"]["humidity"]
                        wind_speed = item["wind"]["speed"]
                        weather = item["weather"][0]["description"]

                        forecast_data.append({
                            "Time": dt_txt,
                            "Temperature (°C)": temp,
                            "Weather": weather,
                            "Humidity (%)": humidity,
                            "Wind Speed (m/s)": wind_speed,
                        })

                        with st.container():
                            cols = st.columns([1, 3])
                            with cols[0]:
                                if "rain" in weather.lower():
                                    st.image(
                                        "https://cdn-icons-png.flaticon.com/512/1163/1163624.png",
                                        use_column_width=True
                                    )
                                    rain_expected = True
                            with cols[1]:
                                st.markdown(f"**🕒 {dt_txt}**")
                                st.markdown(f"🌡 **Temperature**: {temp}°C")
                                st.markdown(f"☁️ **Weather**: {weather}")
                                st.markdown(f"💧 **Humidity**: {humidity}%")
                                st.markdown(f"🌬 **Wind Speed**: {wind_speed} m/s")
                                if "rain" in weather.lower():
                                    st.markdown(
                                        "<div style='color: red; font-weight: bold; font-size: 18px;'>🚨 Rain Alert: Rain may affect the match!</div>",
                                        unsafe_allow_html=True
                                    )
                            st.markdown("---")

                if forecast_data:
                    df = pd.DataFrame(forecast_data)
                    csv_filename = f"{match_choice.replace(' ', '_').replace('(', '').replace(')', '')}_forecast.csv"
                    df.to_csv(csv_filename, index=False)

                    render_left_aligned_table(df)

                    st.success(f"✅ Forecast data saved to `{csv_filename}`")
                    with open(csv_filename, "rb") as file:
                        st.download_button("📥 Download CSV Forecast", file, file_name=csv_filename, mime="text/csv")

                    if rain_expected:
                        st.image("https://cdn-icons-png.flaticon.com/512/1779/1779940.png", width=80)
                        st.error("🚨 Real-Time Alert: Rain is likely during the match! Keep an umbrella handy.")
                    else:
                        st.balloons()
                        st.success("✅ No rain expected. Match should proceed smoothly.")
                else:
                    st.warning("⚠️ No forecast data found for this match date.")

    except Exception as e:
        st.error(f"🚫 Error: {str(e)}")
